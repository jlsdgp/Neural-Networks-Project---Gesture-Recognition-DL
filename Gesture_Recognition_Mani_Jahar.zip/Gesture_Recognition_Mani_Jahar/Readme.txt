The zip file contains the following files.

1) Model 8 which is the final selected model (Which adheres to the evaluation rubric criteria)
File name:  3DConv_Model_8_Neural_Networks_Gesture_Recognition_FINAL_SELECT.ipynb

2) All the other Models/Variations file that were part of the experiments conducted
(Total 10 ipynb including the above Model 8)

3) Write-up on the model building (word document) (As per the requirement of the evaluation rubric criteria)

4) Model File
File Name : model-00014-0.31685-0.87908-0.36788-0.88000.h5 
Batch Size:20 and No of Epochs 20 
Epoch 14/20 
34/34 [==============================] - 13s 389ms/step - loss: 0.3169 - categorical_accuracy: 0.8791 - val_loss: 0.3679 - val_categorical_accuracy: 0.8800 
Epoch 00014: saving model to model_init_2020-03-3011_11_51.849206/model-00014-0.31685-0.87908-0.36788-0.88000.h5 

Note : 
All the model files are executed and run in upgrad provided nimblebox setup with the provided data files (already available in nimblebox)